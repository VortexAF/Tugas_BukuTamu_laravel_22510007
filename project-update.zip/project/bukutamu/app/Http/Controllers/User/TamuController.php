<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class TamuController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('index', compact('users'));
    }

    public function simpanTamu(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'telepon' => 'required',
            'email' => 'required|email',
        ]);

        $user = new User();
        $user->nama = $request->nama;
        $user->tlp = $request->telepon;
        $user->email = $request->email;
        $user->alamat = $request->alamat;
        $user->password = Hash::make('rahasia');
        $user->save();

        return redirect()->route('index')->with('status', 'Data berhasil disimpan')->with('scroll', true);
    }

    public function edit(Request $request, $id)
    {
        $user = User::findOrFail($id);
        if ($request->isMethod('post')) {
            $request->validate([
                'nama' => 'required',
                'telepon' => 'required',
                'email' => 'required|email',
            ]);

            $user->nama = $request->nama;
            $user->tlp = $request->telepon;
            $user->email = $request->email;
            $user->alamat = $request->alamat;
            $user->save();

            return redirect()->route('index')->with('status', 'Data berhasil diperbarui');
        }
        return view('edit', compact('user'));
    }

    public function hapus($id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        return redirect()->route('index')->with('status', 'Data berhasil dihapus');
    }
    public function update(Request $request, $id)
    {
        // Validasi input
        $request->validate([
            'nama' => 'required',
            'telepon' => 'required',
            'email' => 'required|email',
            'alamat' => 'required',
        ]);

        // Temukan pengguna berdasarkan ID
        $user = User::findOrFail($id);

        // Perbarui data pengguna
        $user->update([
            'nama' => $request->nama,
            'telepon' => $request->telepon,
            'email' => $request->email,
            'alamat' => $request->alamat,
        ]);


        return redirect()->route('index')->with('success', 'Data berhasil diperbarui');

    }
}