<!doctype html>
<html lang="en">
<head>
    <title>Edit Data Tamu</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/css/style.css')); ?>">
</head>
<body>
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 text-center mb-5">
                    <h2 class="heading-section">Edit Data Tamu</h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-10">
                    <div class="wrap d-md-flex">
                        <div class="img" style="background-image: url(<?php echo e(url('/frontend/images/bg-1.jpg')); ?>);"></div>
                        <div class="login-wrap p-4 p-md-5">
                            <div class="d-flex">
                                <div class="w-100">
                                    <h3 class="mb-4">Form Edit Data Tamu</h3>
                                </div>
                            </div>
                            <form action="<?php echo e(route('update', $user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-group mb-3">
                                    <label class="label" for="name">Nama</label>
                                    <input type="text" class="form-control" name="nama" value="<?php echo e($user->nama); ?>" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="label" for="telepon">Telepon</label>
                                    <input type="text" name="telepon" class="form-control" value="<?php echo e($user->tlp); ?>" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="label" for="email">Email</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="label" for="alamat">Alamat</label>
                                    <textarea name="alamat" class="form-control" cols="3" required><?php echo e($user->alamat); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="form-control btn btn-primary rounded submit px-3">Simpan Perubahan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="<?php echo e(asset('/frontend/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/frontend/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('/frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/frontend/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\project\bukutamu\resources\views/edit.blade.php ENDPATH**/ ?>