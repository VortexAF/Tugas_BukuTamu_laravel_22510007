<?php
namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class TamuController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('index', compact('users'));
    }

    public function simpanTamu(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'telepon' => 'required',
            'email' => 'required|email',
        ]);

        $user = new User();
        $user->nama = $request->nama;
        $user->tlp = $request->telepon;
        $user->email = $request->email;
        $user->alamat = $request->alamat;
        $user->password = Hash::make('rahasia');
        $user->save();

        return redirect('/')->with('status', 'Data Berhasil Disimpan')->with('scroll', true);
    }
}